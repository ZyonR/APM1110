library(shiny)
library(shinydashboard)
library(tidyverse)
library(DT)
library(echarts4r)
library(shinyWidgets)
library(shiny)

ui<-dashboardPage(skin = "black",
                  dashboardHeader(title="SA1 Ramilo-Dacanay"),
                  dashboardSidebar(
                    sidebarMenu(
                      menuItem("3 Factories Problem",tabName = "factory-problem",icon = icon("industry")),
                      menuItem("Front End Univariate & Bivariate",tabName = "univariate-bivariate",icon = icon("square")),
                      menuItem("Search Engine Simulation",tabName = "search-engine-simulation",icon = icon("magnifying-glass"))
                    )
                  ),
                  dashboardBody(
                    tabItems(
                      tabItem(tabName = "factory-problem",
                              box(width = 12,status = "primary",
                                  title = "Factory Problem",
                                  fluidRow(
                                    column(width = 6,
                                         p("Please Express in Decimal Form.")
                                    )),
                                  column(width = 6,
                                         uiOutput("input_x1"),
                                         uiOutput("input_x2"),
                                         actionBttn("validateInput",
                                                    label = "Enter",
                                                    style = "pill",
                                                    color = "primary",
                                                    size = "xs",
                                                    block = FALSE,
                                                    no_outline = TRUE
                                         )
                                         ),
                                  column(width = 6,
                                         uiOutput("input_y1"),
                                         uiOutput("input_y2")
                                  )
                                  ),
                              box(width = 12,status = "primary",
                                  column(width = 6,
                                         fluidRow("The probability that a randomly selected product is defective.")
                                         ),
                                  column(width = 6,verbatimTextOutput("defective_probab")))
                              ),
                      tabItem(tabName = "univariate-bivariate",
                              box(width = 12,status = "primary",h3("Univariate")),
                              column(width = 6,
                                     box(width = 12,status = "primary",
                                         column(width=6,
                                                uiOutput("newOutcome")
                                                ),
                                         column(width=6,
                                                uiOutput("newProbab")
                                                ),
                                     fluidRow(column(width = 12,
                                       actionBttn("insertValues",
                                                  label = "Insert Values",
                                                  style = "pill",
                                                  color = "primary",
                                                  size = "xs",
                                                  block = FALSE,
                                                  no_outline = TRUE
                                       ),
                                       actionBttn("clearValues",
                                                  label = "Clear Values",
                                                  style = "pill",
                                                  color = "success",
                                                  size = "xs",
                                                  block = FALSE,
                                                  no_outline = TRUE
                                       )
                                      )),
                                         DTOutput("univariateTable")
                                         )
                                     ),
                              column(width = 6,
                                     tabBox(width=12,
                                       tabPanel(title = "Probability Density Function",
                                                fluidRow(plotOutput("plot_univar"))
                                              ),
                                       tabPanel(title = "Cummulative Density Function",
                                                fluidRow(plotOutput("cumSum_univar"))
                                       ),
                                       tabPanel(title = "Mean & Variance",
                                         fluidRow(column(width = 6,
                                                verbatimTextOutput("mean_univar")
                                                ),
                                         column(width = 6,
                                                verbatimTextOutput("var_univar")
                                                ))
                                       )
                                       )
                                     ),
                              box(width = 12,status = "primary",h3("Bivariate")),
                              column(width = 6,
                                     box(width = "12",title = "Bivariate Inputs")
                                     ),
                              column(width = 6)
                              ),
                      tabItem(tabName = "search-engine-simulation",
                              column(width = 6,
                                     box(width = 12, status = "primary",
                                         fluidRow(column(width = 12,
                                                         uiOutput("inputProbab"))),
                                         fluidRow(column(width = 12,
                                                         DTOutput("searchEngineSimulated")))
                                         )
                                     ),
                              column(width = 6,
                                     tabBox(width = 12,
                                       tabPanel(title = "Plot PDF",
                                                echarts4rOutput("plot_searchEngine")
                                                ),
                                       tabPanel(title = "Mean and Variance",
                                                fluidRow(width = 12,
                                                         box(width = 12,"Original Mean and Variance",status = "primary"),
                                                column(width = 6,
                                                       box(width = 12,"Mean"),
                                                       verbatimTextOutput("mean")
                                                       ),
                                                column(width = 6,
                                                       box(width = 12,"Variance"),
                                                       verbatimTextOutput("variance")
                                                )),
                                                fluidRow(width = 12,
                                                         box(width = 12,"Three searches have been carried out without success.",status = "primary"),
                                                         column(width = 6,
                                                                box(width = 12,"Mean"),
                                                                verbatimTextOutput("mean_3")
                                                         ),
                                                         column(width = 6,
                                                                box(width = 12,"Variance"),
                                                                verbatimTextOutput("variance_3")
                                                         ))
                                       )
                                     )
                                     ),
                              box(width = 12,status = "primary",title = "Markov's Property",
                                  column(width = 6,
                                         tags$iframe(style = "width: 100%; height: 600px;",
                                                     src = "Markov_s_Property_on_Geometric_Distribution_Proof.pdf")
                                         ),
                                  column(width = 6,
                                         box(width = 12,status = "primary",
                                             "As test data assume each site has a 60% chance of containing the key phrase.
                                             To satisfy yourself that the Markov memoryless property holds, obtain estimates of
                                             P(X=4|X>3) and P(X=1); P(X=5|X>3) and P(X=2).",
                                             fluidRow(column(width = 6,
                                                    verbatimTextOutput("probab4_given3")
                                                    ),
                                             column(width = 6,
                                                    verbatimTextOutput("probab5_given3")
                                                    ))
                                             )
                                         )
                                  )
                              )
                    )
                  )
                  )
server <- function(input,output,session){
  output$input_x1 <- renderUI({
    numericInput("x1","Product produced by Factory 1:",min = 0.1,max = 0.4,value = 0.1,step = 0.01)
  })
  output$input_x2 <- renderUI({
    numericInput("x2","Product produced by Factory 2:",min = 0.1,max = 0.4,value = 0.1,step = 0.01)
  })
  output$input_y1 <- renderUI({
    numericInput("y1","Defective produced by Factory 1:",min = 0.01,max = 0.05,value = 0.01,step = 0.001)
  })
  output$input_y2 <- renderUI({
    numericInput("y2","Defective produced by Factory 2:",min = 0.01,max = 0.05,value = 0.01,step = 0.001)
  })
  
  observeEvent(input$validateInput,{
    triggered <- FALSE
    input_vector_x <- c(input$x1,input$x2)
    input_vector_y <- c(input$y1,input$y2)
    for(answer in seq_along(input_vector_x)){
      if(input_vector_x[answer]<0.1 | input_vector_x[answer]>0.4){
        showNotification(paste("Error Invalid Value! on","Produced Product Factory ",answer))
        triggered <- TRUE
      }
    }
    for(answer in seq_along(input_vector_y)){
      if(input_vector_y[answer]<0.01 | input_vector_y[answer]>0.05){
        showNotification(paste("Error Invalid Value! on","Defective Product Factory ",answer))
        triggered <- TRUE
      }
    }
    x3 <- reactive({
      1 - input$x1 - input$x2
    })
    y3 <- reactive({
      0.12 - input$y1 - input$y2
    })
    if(!triggered){
      showModal(
        modalDialog(
          title = "YAY 🥳 you have entered valid inputs!",easyClose = TRUE,footer = NULL,
               fluidRow(box(width = 12,status = "primary",
                   paste("Factory 3 is calculated to be ",x3()," and its defective products is calculated to be ",y3(),". Please click anywhere to close.")))
        )
      )
    }
    input_vector_x <- c(input_vector_x,x3())
    input_vector_y <- c(input_vector_y,y3())
    propability <- c()
    for(i in seq_along(input_vector_x)){
      probab <- input_vector_x[i]*input_vector_y[i]
      propability <- c(propability,probab)
    }
    defective_probab <- reactive({
      sum(propability)
    })
    output$defective_probab <- renderPrint({
      defective_probab()
    })
  })
  output$inputProbab<- renderUI({
    numericInput("keyWordProbab","Input Probability of finding Keyword: ",min = 0,max = 1,value = 0.1,step = 0.01)
  })
  simulateSearch <- reactive({
    data <- data.frame(Search_Number = 1:10000, 
                       Number_of_Searches = rgeom(10000, input$keyWordProbab))
    return(data)
  })
  output$searchEngineSimulated <- renderDT({
    datatable(simulateSearch(),
              colnames = c("Search Number","N Searches Before Key is Found"),
              options = list(scrollY="25vh",scrollX="100%")
              )
  })
  observeEvent(input$keyWordProbab,{
    if(input$keyWordProbab<0 | input$keyWordProbab>1){
      showNotification("Error Invalid Value! Only Values from 0 to 1 Please!")
    }
  })
  output$plot_searchEngine<-renderEcharts4r({
    simulateSearch() %>% 
      group_by_(~Number_of_Searches) %>% 
      summarise(PDF = n()/10000) %>% 
      e_charts(Number_of_Searches) %>% 
      e_line(PDF) %>% 
      e_tooltip()
  })
  output$mean<-renderPrint({
    mean(simulateSearch()$Number_of_Searches)
  })
  output$variance<-renderPrint({
    var(simulateSearch()$Number_of_Searches)
  })
  simulateSearch_3<-reactive({
    data <- simulateSearch()
    data[data$Number_of_Searches > 3, ]
  })
  output$mean_3<-renderPrint({
    mean(simulateSearch_3()$Number_of_Searches - 3)
  })
  output$variance_3<-renderPrint({
    var(simulateSearch_3()$Number_of_Searches - 3)
  })
  output$newOutcome <- renderUI({
    numericInput("x_value","Input x value (natural numbers only): ",min = 0,value = 0,step = 1)
  })
  output$newProbab<-renderUI({
    numericInput("x_probab","Input x's probability (0 to 1 only): ",min = 0,max=1,value = 0,step = 0.01)
  })
  x_val <- reactiveVal(c())
  y_prob <- reactiveVal(c())
  observeEvent(input$insertValues,{
    valid<-T
    if(input$x_value<0 | input$x_value %in% x_val()){
      showNotification("Error Invalid Value! Only Natural Numbers Please! and only Unique X")
      valid<-F
    }
    if(input$x_probab<0 | input$x_probab>1){
      showNotification("Error Invalid Value! Only from 0 to 1 Please!")
      valid<-F
    }
    if(sum(y_prob())+input$x_probab>1){
      showNotification("Error Invalid Value! It already equates to 1!")
      updateNumericInput(session, "x_probab", value = 1 - sum(y_prob()))
      valid<-F
      showModal(
        modalDialog(
          title = paste("Switching to Default Value",input$x_prob),easyClose = TRUE,footer = NULL,
          fluidRow(box(width = 12,status = "primary","Please click anywhere to close."))
        )
      )
    }
    if(valid){
      updateNumericInput(session, "x_value", value = input$x_value+1)
      x_val(c(x_val(), input$x_value))
      y_prob(c(y_prob(), input$x_probab))
    }
  })
  univariate<-reactive({
    data<-data.frame(Events = x_val(),
                     Probability = y_prob()
                     )
    return(data)
  })
  output$univariateTable <- renderDT({
    datatable(univariate(),
              colnames = c("Events","Probability"),
              options = list(scrollY="25vh",scrollX="100%")
    )
  })
  observeEvent(input$clearValues,{
    updateNumericInput(session, "x_value", value = 0)
    x_val(c())
    y_prob(c())
  })
  output$plot_univar <- renderPlot({
    req(!is.null(univariate()), !is.null(x_val()), !is.null(y_prob()))
    ggplot(data = univariate(), aes(x = Events, y = Probability,fill="lightblue")) +
      geom_bar(stat = "identity") +
      labs(x = "Events", y = "Probability") +
      ggtitle("Bar Chart of Events vs Probability")+
      theme(legend.position = "none")
  })
  output$cumSum_univar <- renderPlot({
    req(!is.null(univariate()), !is.null(x_val()), !is.null(y_prob()))
    
    univariate_data <- univariate()
    univariate_data$Cumulative_Probability <- cumsum(univariate_data$Probability)
    
    ggplot(data = univariate_data, aes(x = Events, y = Cumulative_Probability)) +
      geom_step() +
      labs(x = "Events", y = "Cumulative Probability", title = "Cumulative Distribution Function") +
      theme_minimal() +
      theme(legend.position = "none")
  })
  output$mean_univar<-renderPrint({
    paste("Mean: ",sum(univariate()$Events*univariate()$Probability))
  })
  output$var_univar<-renderPrint({
    mean<-sum(univariate()$Events*univariate()$Probability)
    variance<-sum(((univariate()$Events-mean)^2)*univariate()$Probability)
    
    return(paste("Variance: ",variance))
  })
  output$probab4_given3 <- renderPrint({
    p <- 0.6
    k<- 4
    probability4 <- (((1-p)^(k-1))*p)/(1-p)^3
    probability1 <- ((1-p)^(1-1))*p
    print(paste("P(X=4|X>3):",probability4,"and P(X=1): ",probability1))
  })
  output$probab5_given3 <- renderPrint({
    p <- 0.6
    k<- 5
    probability5 <- (((1-p)^(k-1))*p)/(1-p)^3
    probability2 <- ((1-p)^(2-1))*p
    print(paste("P(X=5|X>3):",probability5,"and P(X=2): ",probability2))
  })
}
shinyApp(ui=ui,server=server)
